import Calamansi from './calamansi/Calamansi';
import CalamansiEventHub from './calamansi/CalamansiEventHub';

window.Calamansi = Calamansi;
window.CalamansiEvents = new CalamansiEventHub();
